from tortoise import Tortoise
from config import DATABASE_URL

async def init_db(app=None):
    await Tortoise.init(
        db_url=DATABASE_URL,
        modules={"models": ["models.todo", "models.user"]}
    )
    await Tortoise.generate_schemas()
DATABASE_URL = "postgres://postgres:Minicooper@123$@localhost:5432/tododb"
SECRET_KEY = "your_very_secret_key"

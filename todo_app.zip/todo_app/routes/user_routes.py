import bcrypt
from sanic import Blueprint, response
from manager.user_manager import UserManager
from models.user import User
from utils.jwt_auth import generate_token

bp_user = Blueprint("user")

@bp_user.route("/users", methods=["GET"])
async def list_users(request):
    users = await UserManager.get_all_users()
    return response.json(users)

@bp_user.route("/create_users", methods=["POST"])
async def create_user(request):
    data = request.json
    user = await UserManager.create_user(data)
    return response.json({"id": user.id, "username": user.username}, status=201)

@bp_user.route("/users/<user_id:int>", methods=["DELETE"])
async def delete_user(request, user_id):
    user = await UserManager.delete_user(user_id)
    if not user:
        return response.json({"error": "User not found"}, status=404)
    return response.json({"message": "User deleted"})

@bp_user.route("/login", methods=["POST"])
async def login(request):
    data = request.json
    username = data.get("username")
    password = data.get("password")
   
    if not username or not password:
        return response.json({"error": "Username and password are required"}, status=400)

    user = await User.get_or_none(username=username)

    if not user:
        return response.json({"error": "Invalid username or password"}, status=400)

    if not bcrypt.checkpw(password.encode('utf-8'), user.password.encode('utf-8')):
        return response.json({"error": "Invalid username or password"}, status=400)

    token = generate_token(user.id, username)

    return response.json({
        "message": "Login successful",
        "user": {
            "id": user.id,
            "username": user.username,
            "email": user.email
        },
        "token": token 
    })
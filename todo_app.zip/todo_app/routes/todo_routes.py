from sanic import Blueprint, response
from models.todo import Todo
from utils.jwt_auth import decode_token

bp = Blueprint("todo")

@bp.route("/todos", methods=["GET"])
async def list_todos(request):
    todos = await Todo.all().values()
    return response.json(todos)

@bp.route("/todos", methods=["POST"])
async def create_todo(request):
    # Extract the token from the Authorization header
    auth_header = request.headers.get("Authorization")
    if not auth_header:
        return response.json({"error": "Authorization header missing"}, status=401)
    
    token = auth_header.split(" ")[1]  # Assuming "Bearer <token>"
    
    # Decode the token to get the user_id
    user_id, username = decode_token(token)
    if not isinstance(user_id, int):
     return response.json({"error": user_id}, status=401)
    
    # Get data from request
    data = request.json
    data["username"] = username  # Associate the todo with the user

    # Create a new todo
    todo = await Todo.create(**data)
    return response.json({"id": todo.id, "title": todo.title}, status=201)

@bp.route("/updatetodos/<id>", methods=["PUT"])
async def update_todo(request, id):
    todo = await Todo.get_or_none(id=id)
    if not todo:
        return response.json({"error": "Not found in code"}, status=404)
    data = request.json
    await todo.update_from_dict(data).save()
    return response.json({"message": "Updated"})

@bp.route("/deletetodos/<id:int>", methods=["DELETE"])
async def delete_todo(request, id):
    todo = await Todo.get_or_none(id=id)
    if not todo:
        return response.json({"error": "Not found"}, status=404)
    await todo.delete()
    return response.json({"message": "Deleted"})
from tortoise import fields
from tortoise.models import Model

class Todo(Model):
    id = fields.IntField(pk=True) 
    title = fields.CharField(max_length=255)  
    description = fields.TextField(null=True)  
    is_done = fields.BooleanField(default=False) 

    # Foreign key to the User model, linking each todo to a user
    user = fields.ForeignKeyField("models.User", related_name="todos", null= False)

    class Meta:
        table = "todos"
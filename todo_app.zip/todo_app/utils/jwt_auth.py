import jwt
from datetime import datetime, timedelta

from sanic import Unauthorized

SECRET_KEY = "your_secret_key"  

# Function to generate JWT token
def generate_token(user_id, username):
    payload = {
        "user_id": user_id,
        "username": username,
        "exp": datetime.utcnow() + timedelta(hours=1)  # Token expiration after 1 hour
    }
    token = jwt.encode(payload, SECRET_KEY, algorithm="HS256")
    return token  

# Function to decode JWT token
def decode_token(token: str):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms="HS256")
        return payload['user_id'],payload['username']
    except jwt.ExpiredSignatureError:
        raise Unauthorized("Token has expired")
    except jwt.InvalidTokenError:
        raise Unauthorized("Invalid token")
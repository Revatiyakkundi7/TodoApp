from sanic import Sanic
from sanic.response import json
from db.init import init_db
from routes.todo_routes import bp 
from routes.user_routes import bp_user


app = Sanic("TodoApp")
app.blueprint(bp) 
app.blueprint(bp_user) 

@app.route("/")
async def test(request):
    return json({"message": "Hello, world!"})

@app.listener("before_server_start")
async def setup(app, loop):
    await init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=True)
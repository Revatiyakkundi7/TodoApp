import bcrypt
from models.user import User

class UserManager:

    @staticmethod
    async def create_user(data):
        raw_pw = data["password"].encode("utf-8")
        hashed_pw = bcrypt.hashpw(raw_pw, bcrypt.gensalt()).decode("utf-8")
        data["password"] = hashed_pw
        return await User.create(**data)
   
    @staticmethod
    async def get_all_users():
        return await User.all().values("id", "username", "email", "created_at")
    
    @staticmethod
    async def delete_user(user_id):
        user = await User.get_or_none(id=user_id)
        if user:
            await user.delete()
        return user

    @staticmethod
    async def authenticate(email, password):
        user = await User.get_or_none(email=email)
        if user and bcrypt.checkpw(password.encode(), user.password.encode()):
            return user
        return None